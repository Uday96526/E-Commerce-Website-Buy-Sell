import React from "react";
import "./roundloading.css"
function RoundLoading() {
  return (
    <div className="round-loader-container">
      <div className="round-loader">
        <span>Loading...</span>
       
      </div>
    </div>
  );
}

export default RoundLoading;
