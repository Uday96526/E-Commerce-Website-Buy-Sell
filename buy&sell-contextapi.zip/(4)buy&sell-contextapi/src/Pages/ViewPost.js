import React from 'react'

import Header from '../Components/Header/Header'
import View from '../Components/View/View'


function ViewPost(props) {
    return (
        <div>
            
            <Header />
            <View/>
            
        </div>
    )
}

export default ViewPost
