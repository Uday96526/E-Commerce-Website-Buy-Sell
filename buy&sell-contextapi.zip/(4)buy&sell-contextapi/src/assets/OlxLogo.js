import React from 'react'

export default  function OlxLogo() {
    return(  
     <div>
<img src="https://thumbs.dreamstime.com/b/shopping-basket-buy-sell-logo-vector-red-101315335.jpg" style={{height:155,width:155,borderRadius:100}}></img>
     </div>
     )
}






       // width="48px"
       // height="48px"
       // viewBox="0 0 1024 1024"
       // data-aut-id="icon"
       // fillRule="evenodd"