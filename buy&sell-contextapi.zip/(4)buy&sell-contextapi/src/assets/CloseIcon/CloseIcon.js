import React from "react";
import "./closeicon.css";
function CloseIcon() {
  return (
    <div>
      <div className="close"></div>
    </div>
  );
}

export default CloseIcon;
